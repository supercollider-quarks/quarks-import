import sys
sys.path.append( 'src' )
from optparse_gui import __version__

import ez_setup
ez_setup.use_setuptools()

from setuptools import setup, find_packages

setup(
    name = "optparse_gui",
    version = str( __version__ ),
    packages = find_packages(),

    author = "slider fry",
    author_email = "slider.fry@gmail.com",
    description = "import optparse_gui as optparse",
    license = "BSD",
    keywords = "python gui wx commandline",
    url = "http://optparse-gui.googlecode.com",   # project home page, if any
    zip_safe = True,
    #install_requires = [ 'wxPython' ],
    classifiers = [
        'Development Status :: 3 - Alpha',
        'Environment :: Win32 (MS Windows)',
        'Environment :: X11 Applications',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: POSIX',
        'Operating System :: OS Independent',
        'Operating System :: MacOS',
        'Programming Language :: Python',
        'Topic :: Software Development'
    ]
)